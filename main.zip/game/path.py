class Path():
    
    def updatePosition(self, pos, speed, dt):
        return pos